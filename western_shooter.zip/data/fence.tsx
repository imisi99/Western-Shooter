<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="fence" tilewidth="64" tileheight="64" tilecount="144" columns="9">
 <image source="../graphics/tilesets/fence.png" width="632" height="1024"/>
</tileset>
